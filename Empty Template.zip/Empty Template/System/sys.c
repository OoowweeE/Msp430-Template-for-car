#include "sys.h"
#include "driverlib.h"

void MySystem_init(void)
{
	  //��1.�������ⲿ48M���پ���
	  //GPIO_setAsPeripheralModuleFunctionOutputPin(GPIO_PORT_PJ, GPIO_PIN3 | GPIO_PIN2, GPIO_PRIMARY_MODULE_FUNCTION);
    //UCS_setExternalClockSourceFrequency(32768, 48000000);
	  //SysTick_disableInterrupt(); //����ʱ���ж�
    //PCM_setCoreVoltageLevel(PCM_VCORE1);
	  //FlashCtl_setWaitState(FLASH_BANK0, 2);
		//FlashCtl_setWaitState(FLASH_BANK1, 2);
   // CS_startHFXT(false);
    //UCS_initClockSignal(UCS_MCLK, UCS_HFXTCLK_SELECT, CS_CLOCK_DIVIDER_1);
    //CS_initClockSignal(CS_SMCLK, CS_HFXTCLK_SELECT, CS_CLOCK_DIVIDER_1);
	
	  //��2.���رտ��Ź�
	 // WDT_A_holdTimer();

}
