/*
 * clkinit.h
 *
 *  Created on: 2023��7��24��
 *      Author: Chris
 */

#ifndef SYSTEM_CLKINIT_H_
#define SYSTEM_CLKINIT_H_

void initClock(void);

#endif /* SYSTEM_CLKINIT_H_ */
