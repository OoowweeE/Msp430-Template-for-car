#ifndef __DELAY_H
#define __DELAY_H

void delay_ms(unsigned int time);
void delay_us(unsigned int time);
#endif
