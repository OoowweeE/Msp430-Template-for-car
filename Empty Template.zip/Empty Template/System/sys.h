#ifndef __SYS_H__
#define __SYS_H__

void MySystem_init(void);
#endif
