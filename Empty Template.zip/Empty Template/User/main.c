#include <msp430.h> 
#include "driverlib.h"
#include "oled.h"
#include "type.h"
#include "mpu6050.h"
#include "inv_mpu.h"
#include "inv_mpu_dmp_motion_driver.h"
#include "mpuexti.h"
#include "clkinit.h"
#include "pwm.h"
#include "uart1.h"
#include "Led.h"
#include "key.h"
#include "encoder.h"
#include "beep.h"
/**
 * main.c
 */
unsigned int Fre1;
unsigned int Fre2;
void main(void)
{
	WDTCTL = WDTPW | WDTHOLD;	// stop watchdog timer
	initClock();
	OLED_Init();
	OLED_Clear();
	Key_Init();
	Led_Init();
	Beep_Init();
	Led1_On();
	Led2_On();
	MPU_Init();            //MPU6050��ʼ��
	DMP_Init();            //DMP��ʼ��
	MPU_exti_init();       //MPU6050�ⲿ�жϳ�ʼ��
	TA2_PWM_Init();
	//Load_Pwm(3500, 1000);
	//usart0_init();
	encoder1_init();
	encoder2_init();
	while(1){
	    OLED_ShowSignedNum(1,3,left_speed,6);
	    OLED_ShowSignedNum(2,3,right_speed,6);
	    OLED_ShowSignedNum(3,3,Base_x,6);
	    KeyNum=Key_GetNum();
	    if(KeyNum==1){
	        Base_x+=10;

	    }
	    if(KeyNum==2){
	               Base_x-=10;

	           }
	    if(KeyNum==3){
	        GPIO_toggleOutputOnPin (GPIO_PORT_P8, GPIO_PIN2);

	           }

	}
	

}
