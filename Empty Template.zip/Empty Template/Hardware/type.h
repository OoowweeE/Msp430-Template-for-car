/*
 * type.h
 *
 *  Created on: 2023��7��23��
 *      Author: Chris
 */

#ifndef HARDWARE_TYPE_H_
#define HARDWARE_TYPE_H_

#define u32 unsigned int
#define u16 unsigned short
#define u8 unsigned char
//typedef  unsigned char uint8_t;
//typedef  unsigned int uint32_t;
//typedef  unsigned short uint16_t;
//typedef  signed int int32_t;



#endif /* HARDWARE_TYPE_H_ */
