/*
 * beep.c
 *
 *  Created on: 2023��7��30��
 *      Author: Chris
 */
 //����������p8.2
#include "driverlib.h"
#include <msp430.h>
void Beep_Init(void){
    GPIO_setAsOutputPin(GPIO_PORT_P8,GPIO_PIN2);
    GPIO_setOutputLowOnPin (GPIO_PORT_P8, GPIO_PIN2);

}

void Beep_On(void){
    GPIO_setOutputHighOnPin (GPIO_PORT_P8, GPIO_PIN2);
}

void Beep_off(void){
    GPIO_setOutputLowOnPin (GPIO_PORT_P8, GPIO_PIN2);

}
