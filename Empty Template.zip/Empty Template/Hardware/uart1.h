/*
 * uart1.h
 *
 *  Created on: 2023��7��31��
 *      Author: Chris
 */

#ifndef HARDWARE_UART1_H_
#define HARDWARE_UART1_H_

void usart0_init(void);
int openmv_data_test(int data[]);
extern int openmv_data[8];
extern int Base_x;
extern int Up_y;

#endif /* HARDWARE_UART1_H_ */
