/*
 * uart1.c
 *
 *  Created on: 2023��7��31��
 *      Author: Chris
 */
#include <msp430.h>
#include "driverlib.h"
#include "uart1.h"

char data; //���յ��Ĵ�������
int openmv_data[8] = {0,0,0,0,0,0,0,0};
int Base_x;
int Up_y;
void usart0_init(void)
{
    //��ʼ��gpio
    GPIO_setAsPeripheralModuleFunctionInputPin(GPIO_PORT_P3, GPIO_PIN3+GPIO_PIN4);

    USCI_A_UART_initParam usart0_param={0};
    usart0_param.selectClockSource=USCI_A_UART_CLOCKSOURCE_SMCLK;//ѡ��ʱ��,8MHz
    //���ò�����9600hz
    usart0_param.clockPrescalar=19;
    usart0_param.firstModReg=8;
    usart0_param.secondModReg=0;
    usart0_param.overSampling = USCI_A_UART_OVERSAMPLING_BAUDRATE_GENERATION;

    usart0_param.parity = USCI_A_UART_NO_PARITY;   //��У��λ
    usart0_param.msborLsbFirst = USCI_A_UART_LSB_FIRST;  //��λ����
    usart0_param.numberofStopBits = USCI_A_UART_ONE_STOP_BIT;  //1ֹͣλ
    usart0_param.uartMode = USCI_A_UART_MODE;

    USCI_A_UART_init(USCI_A0_BASE, &usart0_param);//���ڳ�ʼ��

    USCI_A_UART_clearInterrupt(USCI_A0_BASE,USCI_A_UART_RECEIVE_INTERRUPT | USCI_A_UART_TRANSMIT_INTERRUPT);//������շ����ж�

    USCI_A_UART_enable(USCI_A0_BASE);//����ʹ��
    USCI_A_UART_enableInterrupt (USCI_A0_BASE, USCI_A_UART_RECEIVE_INTERRUPT);
}



//******************************************************************************
//
//This is the USCI_A0 interrupt vector service routine.
//
//******************************************************************************

#pragma vector=USCI_A0_VECTOR
__interrupt void USCI_A0_ISR (void)
{
    static int i = 0;
    switch (__even_in_range(UCA0IV,4))
    {
        case 0: break;//���ж�
        case 2://�����ж�
            //�������ݣ�
             openmv_data[i++]=USCI_A_UART_receiveData(USCI_A0_BASE);
                  if(openmv_data[0]!=0xa3) i=0; //�жϵ�һ��֡ͷ
                  if((i==2)&&(openmv_data[1]!=0xb3)) i=0; //�жϵڶ���֡ͷ
                  if(i==5){
                     i=0;
                     if(openmv_data_test(openmv_data)){

                        Base_x = openmv_data[2];
                        Up_y   = openmv_data[3];
                                          }
                           }
            break;
        case 4: break;//�����ж�
        default: break;
    }

}


int openmv_data_test(int data[]){
    if(data[0]!=0xa3) return 0;
    if(data[1]!=0xb3) return 0;
    if(data[4]!=0xc3) return 0;

    return 1;
}






