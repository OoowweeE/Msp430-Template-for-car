/*
 * beep.h
 *
 *  Created on: 2023��7��30��
 *      Author: Chris
 */

#ifndef HARDWARE_BEEP_H_
#define HARDWARE_BEEP_H_
void Beep_Init(void);
void Beep_On(void);
void Beep_off(void);
#endif /* HARDWARE_BEEP_H_ */
