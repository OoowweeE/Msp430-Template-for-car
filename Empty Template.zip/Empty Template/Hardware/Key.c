/*
 * Key.c
 *
 *  Created on: 2023��7��30��
 *      Author: Chris
 */
#include <msp430.h>
#include "driverlib.h"
#include "delay.h"
int KeyNum;

void Key_Init(void){
    GPIO_setAsInputPin (GPIO_PORT_P2, GPIO_PIN1);
    GPIO_setAsInputPin (GPIO_PORT_P1, GPIO_PIN1);
    GPIO_setAsInputPin (GPIO_PORT_P1, GPIO_PIN6);
    GPIO_setAsInputPinWithPullUpResistor (GPIO_PORT_P2, GPIO_PIN1);
    GPIO_setAsInputPinWithPullUpResistor (GPIO_PORT_P1, GPIO_PIN1);
    GPIO_setAsInputPinWithPullUpResistor (GPIO_PORT_P1, GPIO_PIN6);

}

unsigned char Key_GetNum(void){ //��������Ϊ1 û����Ϊ0
    unsigned char KeyNum=0;

    if(GPIO_getInputPinValue (GPIO_PORT_P2, GPIO_PIN1)==0){ //��������
        delay_ms(20);
        while(GPIO_getInputPinValue (GPIO_PORT_P2, GPIO_PIN1)==0);
        delay_ms(20);
        KeyNum=1;
    }
    if(GPIO_getInputPinValue (GPIO_PORT_P1, GPIO_PIN1)==0){ //��������
        delay_ms(20);
        while(GPIO_getInputPinValue (GPIO_PORT_P1, GPIO_PIN1)==0);
        delay_ms(20);
        KeyNum=2;
    }
    if(GPIO_getInputPinValue (GPIO_PORT_P1, GPIO_PIN6)==0){ //��������
        delay_ms(20);
        while(GPIO_getInputPinValue (GPIO_PORT_P1, GPIO_PIN6)==0);
        delay_ms(20);
        KeyNum=3;
    }
    return KeyNum;  //û�а�������Ĭ�Ϸ���0
}

