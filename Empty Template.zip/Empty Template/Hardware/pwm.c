/*
 * pwm.c
 *
 *  Created on: 2023��7��24��
 *      Author: Chris
 */

//TA2.2 : P2.5  TA2.1 : P2.4 ���pwm
#include "driverlib.h"
#include "msp430.h"
void TA2_PWM_Init(void)
{

    Timer_A_initUpDownModeParam initUpDownParam = {0};
    Timer_A_initCompareModeParam initComp1Param = {0};
    Timer_A_initCompareModeParam initComp2Param = {0};
    //P2.5 and P2.4 output pwm
        GPIO_setAsPeripheralModuleFunctionOutputPin(
            GPIO_PORT_P2,
            GPIO_PIN4 + GPIO_PIN5
            );
    //��2�����ö�ʱ��1��
    initUpDownParam.captureCompareInterruptEnable_CCR0_CCIE = TIMER_A_CCIE_CCR0_INTERRUPT_DISABLE; //��ʹ��CCR0�ж�
    initUpDownParam.clockSource = TIMER_A_CLOCKSOURCE_SMCLK;                                       //ʱ��ԴSMCLK24Mhz
    initUpDownParam.clockSourceDivider = TIMER_A_CLOCKSOURCE_DIVIDER_1;                            //��Ƶ
    initUpDownParam.timerClear = TIMER_A_DO_CLEAR;                                                 //���ֵ
    initUpDownParam.timerInterruptEnable_TAIE = TIMER_A_TAIE_INTERRUPT_DISABLE;                    //��ʹ���ж�
    initUpDownParam.captureCompareInterruptEnable_CCR0_CCIE =TIMER_A_CCIE_CCR0_INTERRUPT_DISABLE;  //
    initUpDownParam.timerPeriod = 7200;                                                            //װ��ֵ��װ��ֵ = 24M /Ƶ�ʣ�
    Timer_A_initUpDownMode(TIMER_A2_BASE, &initUpDownParam);                            //���ö�ʱ��2
    Timer_A_startCounter( TIMER_A2_BASE,TIMER_A_UPDOWN_MODE);

    //��3�����ö�ʱ��2ͨ��1��
    initComp1Param.compareInterruptEnable = TIMER_A_CAPTURECOMPARE_INTERRUPT_DISABLE; //��ʹ���ж�
    initComp1Param.compareOutputMode = TIMER_A_OUTPUTMODE_TOGGLE_RESET;               //SET �� RESETռ�ձ��෴
    initComp1Param.compareRegister = TIMER_A_CAPTURECOMPARE_REGISTER_1;               //TA2_CH1
    initComp1Param.compareValue = 0;                                                  //��ʼռ�ձ�
    Timer_A_initCompareMode(TIMER_A2_BASE, &initComp1Param);                        //����TA2_CH1��PWM

    //��3�����ö�ʱ��2ͨ��1��
    initComp2Param.compareInterruptEnable = TIMER_A_CAPTURECOMPARE_INTERRUPT_DISABLE; //��ʹ���ж�
    initComp2Param.compareOutputMode = TIMER_A_OUTPUTMODE_TOGGLE_RESET;               //SET �� RESETռ�ձ��෴
    initComp2Param.compareRegister = TIMER_A_CAPTURECOMPARE_REGISTER_2;               //TA2_CH2
    initComp2Param.compareValue = 0;                                                  //��ʼռ�ձ�
    Timer_A_initCompareMode(TIMER_A2_BASE, &initComp2Param);                        //����TA2_CH1��PWM


}

void Load_Pwm(int Pwm1, int Pwm2){

    //����ռ�ձȣ�
    Timer_A_setCompareValue(TIMER_A2_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_1, Pwm2); //ռ�ձ�50% TA2.1  P2.4 pwmB �ҵ��
    Timer_A_setCompareValue(TIMER_A2_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_2, Pwm1); //ռ�ձ�50% TA2.2  P2.5 pwmA ����



}
