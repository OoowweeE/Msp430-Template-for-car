/*
 * Key.h
 *
 *  Created on: 2023��7��30��
 *      Author: Chris
 */

#ifndef HARDWARE_KEY_H_
#define HARDWARE_KEY_H_
void Key_Init(void);
unsigned char Key_GetNum(void);
extern int KeyNum;


#endif /* HARDWARE_KEY_H_ */
