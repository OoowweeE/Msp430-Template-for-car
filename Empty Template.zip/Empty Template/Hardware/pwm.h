/*
 * pwm.h
 *
 *  Created on: 2023��7��24��
 *      Author: Chris
 */

#ifndef HARDWARE_PWM_H_
#define HARDWARE_PWM_H_

void TA2_PWM_Init(void);
void Load_Pwm(int Pwm1, int Pwm2);

#endif /* HARDWARE_PWM_H_ */
