/*
 * Led.h
 *
 *  Created on: 2023��7��30��
 *      Author: Chris
 */

#ifndef HARDWARE_LED_H_
#define HARDWARE_LED_H_
void Led_Init(void);
void Led1_On(void);
void Led2_On(void);
void Led1_Off(void);
void Led2_Off(void);
#endif /* HARDWARE_LED_H_ */
