/*
 * Led.c
 *
 *  Created on: 2023��7��30��
 *      Author: Chris
 */
#include <msp430.h>
#include "driverlib.h"
void Led_Init(void){
    GPIO_setAsOutputPin(GPIO_PORT_P4,GPIO_PIN1);
    GPIO_setAsOutputPin(GPIO_PORT_P4,GPIO_PIN2);
    GPIO_setOutputLowOnPin (GPIO_PORT_P4, GPIO_PIN1);
    GPIO_setOutputLowOnPin (GPIO_PORT_P4, GPIO_PIN2);
}

void Led1_On(void){

    GPIO_setOutputLowOnPin (GPIO_PORT_P4, GPIO_PIN1);
}

void Led2_On(void){
    GPIO_setOutputLowOnPin (GPIO_PORT_P4, GPIO_PIN2);
}

void Led1_Off(void){

    GPIO_setOutputHighOnPin (GPIO_PORT_P4, GPIO_PIN1);

}
void Led2_Off(void){

    GPIO_setOutputHighOnPin (GPIO_PORT_P4, GPIO_PIN2);

}
